# Data science intern task 

# Getting started

## Poetry
For environment and dependencies management, `poetry` is the preferred dependency manager. 

### Installation
Installation instructions can be found [here](https://python-poetry.org/docs/#installation).

### Prepare environment
To install the packages in `pyproject.toml`, run

```sh
poetry install 
```


